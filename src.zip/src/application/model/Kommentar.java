package application.model;

public class Kommentar {
    private String kommentar;

    public Kommentar(String kommentar) {
        this.kommentar = kommentar;
    }

    public void setKommentar(String kommentar) {
        this.kommentar = kommentar;
    }

    public String getKommentar() {
        return kommentar;
    }

    @Override
    public String toString() {
        return kommentar;
    }
}
