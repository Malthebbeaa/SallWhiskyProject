package application.model;

public class Rygemateriale {
    private String type;

    public Rygemateriale(String type) {
        this.type = type;
    }
}
