package gui;

public interface GuiObserver {

    void update(GuiSubject s);
}
